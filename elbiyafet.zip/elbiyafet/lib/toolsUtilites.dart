import 'package:flutter/material.dart';

class Toolsutilites {
  //الالوان الرئيسية
  //عملتن ستاتيك لحتى اقدر استدعيه دغري بدون ما اعمل انستنس منه
  static final yellowColor = Color(0xfff7b731);
  static final mainColor = Color(0xff7a9c59);
  static final secondColor = Color(0xff313033);
  static final whiteColor = Color(0xffffffff);
  static final greyColor = Color(0xff8f8f8f);
}


