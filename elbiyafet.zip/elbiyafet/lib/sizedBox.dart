import 'package:flutter/material.dart';

Widget sortSizedBox0() {
  return SizedBox(
    height: 5,
  );
}

Widget sortSizedBox1() {
  return SizedBox(
    height: 15,
  );
}

Widget sortSizedBox() {
  return SizedBox(
    height: 20,
  );
}

Widget longSizedBox() {
  return SizedBox(
    height: 100,
  );
}

Widget middleSizedBox() {
  return SizedBox(
    height: 50,
  );
}
